package GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Otherlib_discussionroom_studycarrel_2 {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Otherlib_discussionroom_studycarrel_2 window = new Otherlib_discussionroom_studycarrel_2();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Otherlib_discussionroom_studycarrel_2() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1035, 720);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton_1 = new JButton("\u56DE\u9996\u9801");
		btnNewButton_1.setBounds(114, 40, 85, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("\u7814\u7A76\u5C0F\u9593");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(506, 44, 77, 15);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("\u767B\u51FA");
		btnNewButton_2.setBounds(895, 40, 85, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton = new JButton("\u9810\u7D04");
		btnNewButton.setBounds(100, 244, 85, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_3 = new JButton("\u501F\u95B1\u7D00\u9304");
		btnNewButton_3.setBounds(100, 415, 85, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5\u6708");
		btnNewButton_4.setBounds(228, 129, 85, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("6\u6708");
		btnNewButton_5.setBounds(361, 129, 85, 23);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("7\u6708");
		btnNewButton_6.setBounds(486, 129, 85, 23);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("8\u6708");
		btnNewButton_7.setBounds(605, 129, 85, 23);
		frame.getContentPane().add(btnNewButton_7);
		
		JLabel lblNewLabel_1 = new JLabel("\u7B2C\u4E00\u5340");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(201, 361, 46, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\u7B2C\u4E8C\u5340");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(395, 288, 46, 19);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("\u7B2C\u4E09\u5340");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setBounds(539, 351, 46, 19);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("\u7B2C\u56DB\u5340");
		lblNewLabel_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_2.setBounds(786, 288, 46, 19);
		frame.getContentPane().add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_2 = new JLabel("\u7B2C\u4E94\u5340");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setBounds(952, 353, 46, 15);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JButton btnNewButton_9 = new JButton("\u7B2C\u4E00\u5340");
		btnNewButton_9.setBounds(257, 559, 85, 23);
		frame.getContentPane().add(btnNewButton_9);
		
		JButton btnNewButton_9_1 = new JButton("\u7B2C\u4E8C\u5340");
		btnNewButton_9_1.setBounds(388, 559, 85, 23);
		frame.getContentPane().add(btnNewButton_9_1);
		
		JButton btnNewButton_9_2 = new JButton("\u7B2C\u4E09\u5340");
		btnNewButton_9_2.setBounds(506, 559, 85, 23);
		frame.getContentPane().add(btnNewButton_9_2);
		
		JButton btnNewButton_9_3 = new JButton("\u7B2C\u56DB\u5340");
		btnNewButton_9_3.setBounds(617, 559, 85, 23);
		frame.getContentPane().add(btnNewButton_9_3);
		
		JButton btnNewButton_9_4 = new JButton("\u7B2C\u4E94\u5340");
		btnNewButton_9_4.setBounds(723, 559, 85, 23);
		frame.getContentPane().add(btnNewButton_9_4);
		
		JLabel lblNewLabel_2 = new JLabel("401");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(257, 361, 46, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("402");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setBounds(257, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("403");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2.setBounds(257, 419, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("404");
		lblNewLabel_2_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_3.setBounds(257, 443, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel("405");
		lblNewLabel_2_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_4.setBounds(257, 468, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_2_5 = new JLabel("421");
		lblNewLabel_2_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_5.setBounds(894, 361, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_5);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("422");
		lblNewLabel_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1_1.setBounds(894, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_2_2_1 = new JLabel("423");
		lblNewLabel_2_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2_1.setBounds(894, 419, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_2_1);
		
		JLabel lblNewLabel_2_3_1 = new JLabel("424");
		lblNewLabel_2_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_3_1.setBounds(894, 443, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_3_1);
		
		JLabel lblNewLabel_2_4_1 = new JLabel("425");
		lblNewLabel_2_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_4_1.setBounds(894, 468, 46, 15);
		frame.getContentPane().add(lblNewLabel_2_4_1);
		
		JLabel lblNewLabel_3 = new JLabel("406");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(296, 248, 46, 15);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("407");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setBounds(337, 248, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("408");
		lblNewLabel_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2.setBounds(380, 248, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_3_3 = new JLabel("409");
		lblNewLabel_3_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_3.setBounds(427, 248, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_3);
		
		JLabel lblNewLabel_3_4 = new JLabel("410");
		lblNewLabel_3_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_4.setBounds(472, 248, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_4);
		
		JLabel lblNewLabel_3_5 = new JLabel("411");
		lblNewLabel_3_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_5.setBounds(455, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_5);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("412");
		lblNewLabel_3_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_1.setBounds(496, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("413");
		lblNewLabel_3_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2_1.setBounds(539, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_2_1);
		
		JLabel lblNewLabel_3_3_1 = new JLabel("414");
		lblNewLabel_3_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_3_1.setBounds(586, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_3_1);
		
		JLabel lblNewLabel_3_4_1 = new JLabel("415");
		lblNewLabel_3_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_4_1.setBounds(631, 389, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_4_1);
		
		JLabel lblNewLabel_3_6 = new JLabel("416");
		lblNewLabel_3_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_6.setBounds(702, 244, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_6);
		
		JLabel lblNewLabel_3_1_2 = new JLabel("417");
		lblNewLabel_3_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_2.setBounds(743, 244, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_1_2);
		
		JLabel lblNewLabel_3_2_2 = new JLabel("418");
		lblNewLabel_3_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2_2.setBounds(786, 244, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_2_2);
		
		JLabel lblNewLabel_3_3_2 = new JLabel("419");
		lblNewLabel_3_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_3_2.setBounds(833, 244, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_3_2);
		
		JLabel lblNewLabel_3_4_2 = new JLabel("420");
		lblNewLabel_3_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_4_2.setBounds(878, 244, 46, 15);
		frame.getContentPane().add(lblNewLabel_3_4_2);
		
		JButton btnNewButton_8 = new JButton("401");
		btnNewButton_8.setBounds(162, 618, 85, 23);
		frame.getContentPane().add(btnNewButton_8);
		
		JButton btnNewButton_8_1 = new JButton("402");
		btnNewButton_8_1.setBounds(257, 618, 85, 23);
		frame.getContentPane().add(btnNewButton_8_1);
		
		JButton btnNewButton_8_2 = new JButton("403");
		btnNewButton_8_2.setBounds(361, 618, 85, 23);
		frame.getContentPane().add(btnNewButton_8_2);
		
		JButton btnNewButton_8_3 = new JButton("404");
		btnNewButton_8_3.setBounds(470, 618, 85, 23);
		frame.getContentPane().add(btnNewButton_8_3);
		
		JButton btnNewButton_8_4 = new JButton("405");
		btnNewButton_8_4.setBounds(581, 618, 85, 23);
		frame.getContentPane().add(btnNewButton_8_4);
		
		frame.setVisible(true);
	}

}

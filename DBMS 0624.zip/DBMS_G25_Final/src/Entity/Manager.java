package Entity;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class Manager extends ConnectDb {

	public boolean execute(String query) {
		super.connect();
		try {
			Statement stmt = conn.createStatement();
			if (stmt.executeUpdate(query) != 0) {
				return true;
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			super.closeConn();
		}
		return false;
	}

	public boolean seatUpdate(String locat_id, String seat_id, String newStatus) {
		String query;
		if (Integer.parseInt(locat_id) <= 3) {
			query = "UPDATE Room SET room_status = '" + newStatus + "' WHERE locat_id = '" + locat_id
					+ "' AND room_id = '" + seat_id + "'";
		} else {
			query = "UPDATE Seat SET seat_status = '" + newStatus + "' WHERE locat_id = '" + locat_id
					+ "' AND seat_id = '" + seat_id + "'";
		}

		return execute(query);
	}

	public boolean seatUpdate(String locat_id, String newStatus) {
		ArrayList<String> seats = new ArrayList<String>();
		try {
			String getId;
			if (Integer.parseInt(locat_id) <= 3) {
				getId = "SELECT room_id FROM Room WHERE locat_id = " + locat_id;
			} else {
				getId = "SELECT seat_id FROM Seat WHERE locat_id = " + locat_id;
			}

			super.connect();
			Statement stmt = conn.createStatement();
			ResultSet result = stmt.executeQuery(getId);
			while (result.next()) {
				seats.add(result.getString(1));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return false;
		} finally {
			super.closeConn();
		}
		
		for (String sid : seats) {
			if (!seatUpdate(locat_id, sid, newStatus)) {
				return false;
			}
		}
		return true;
	}
}
